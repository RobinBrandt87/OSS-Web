<?php
  include_once "./src/php_funcs.php";
  include_once "./src/db_funcs.php";
/*##########################################################################################
function PrintErrorDiv( $errno )

Diese Funktion erzeugt ein gültiges html Div der Klasse error mit Formatierter 
Fehlerbeschreibung

Parameter:			$errno eien Fehlernummer bisher vergeben siehe switch-case  
 					$error

Rückgabewert:		das Fertige html div als string 

#########################################################################################*/
function PrintErrorDiv( $errno )
{
	switch ($errno)
	{
		case 10:	
			$title = "Falsche Anmeldedaten";
			$desc  = "Diese Kombination aus Benutzername und Passwort ist ungültig. Bitte geben Sie Ihre korrekten Daten erneut ein.";
			break;
			
		case 11:
			$title = "Falsche Anmeldedaten";
			$desc  = "Diese Kombination aus Benutzername und Passwort ist ungültig. Bitte geben Sie Ihre korrekten Daten erneut ein.";
			break;
		
		case 9:
			$title = "Sie sind NICHT Angemeldet";
			$desc  = "Bitte Melden SIE sich mit ihren Nutzerdaten AN";
			break; 	
		
		default:
			$title = "Unbekannter Fehler";
			$desc  = "Sorry das hätte nicht passieren dürfen";
		
					
	}
	
        // Fehlermeldung: Falsche Anmeldedaten
				$errmsg = 
					"\n<div class=\"error\">".
					"\n\t<div class=\"title\">".$title."</div>".
				  "\n\t<div class=\"desc\">".$desc."</div>";
return $errmsg;				  
}
/*#####################################################################################
	Print_MitarbeiterTable($Mitarbeiterrarr);
	
	Diese Funktion erzeugt ein gültiges XHTML DIV mit einer gültigen HTML Tabelle mit allen MitarbeiterDaten
	
	Parameter 
    
	$lehrerarr		 Ein Zweidiemensianalen assioziatives array aller Mitarbeiter
	$OptionalerParm  Ein Optionaler Parameter der zur Bearbeiten ausgabe 
    
	rückgabe 		 das fertige html Div als String 
	
	#####################################################################################*/
	function Print_MitarbeiterTable($Mitarbeiterarr, $OptionalerParm)
	{
     
		// der tabenlenkopf
		$table = 
        "<form method=\"POST\"".
                   "action=".$_SERVER['PHP_SELF']."?".SID 
                   ." <input  type=\"hidden\"".
              "name=\"<?php echo session_name();?>\" 
              value=\"<?php echo session_id();?>\" />".
	"\n<table id=\"lehrertab\">
	 \n	<thead>
	 \n		<tr>
	 \n			<th>ID</th>
	 \n			<th>Vorname</th>
	 \n			<th>Nachname</th>
     \n			<th>Dienst E-mail</th>
     \n			<th>Straße</th>
     \n			<th>Ort</th>
     \n			<th>PLZ</th>
     \n			<th>Geburtstag</th>
     \n			<th>Einstell-Datum</th>
	 \n			<th>Staus</th>
     \n			<th></th>
     \n			<th>Login </th>
	 \n			<th>Aktiv</th>
	 \n		</tr>
	 \n	</thead>
	 \n	<tbody>";
	 // Hier kommen in einer Schleife alle tabelenzeilen hin n mal 
     foreach($Mitarbeiterarr AS $Mitarbeiter)
	{
 
	// $lehrer ist immernoch ein eindimensionale assoziatives array
	if ($Mitarbeiter['MitarbeiterID'] != $OptionalerParm) {
            $dbconn = dbconnect("HssUser","oss_test");
            $Status = DarfErDas($dbconn, $Mitarbeiter['MitarbeiterID']);
            if ($Status['0']['Status']=='Ok') {
               $option="\n	<td><input  type=\"submit\" class=\"Sperren\" name=\"Sperren\" value=\"".$Mitarbeiter['MitarbeiterID']."\" /></td>";
            }
            else {
               $option="\n	<td><input  type=\"submit\" class=\"Aktivieren\" name=\"Aktivieren\" value=\"".$Mitarbeiter['MitarbeiterID']."\" /></td>"; 
            }
           
        $table.=
			"\n<tr>".
			"\n	<td>".$Mitarbeiter['MitarbeiterID']."</td>".
			"\n	<td>".$Mitarbeiter['Vname']."</td>".
			"\n	<td>".$Mitarbeiter['Nname']."</td>".
            "\n	<td>".$Mitarbeiter['Dienst_E_Mail']."</td>".
            "\n	<td>".$Mitarbeiter['Str_HN']."</td>".
            "\n	<td>".$Mitarbeiter['Ort']."</td>".
            "\n	<td>".$Mitarbeiter['PLZ']."</td>".
            "\n	<td>".$Mitarbeiter['Geb_Datum']."</td>".
            "\n	<td>".$Mitarbeiter['Einstell_ZS']."</td>".
			"\n	<td>".$Mitarbeiter['Status_MA']."</td>".
            "\n	<td><input  type=\"submit\" name=\"Bearbeiten\" class=\"Bearbeiten\" value=\"".$Mitarbeiter['MitarbeiterID']."\" /></td>".
            $option.
			"\n	<td>".$Status['0']['Status']."</td>".
			"\n  </tr>";
    }
    else {

        $table.=
			"\n<tr>".
			"\n	<td><input type=\"text\" name=\"ID\" value=\"".$Mitarbeiter['MitarbeiterID']."\" readonly /></td>".
			"\n	<td><input type=\"text\" name=\"Vorname\" value=\"".$Mitarbeiter['Vname']."\" /></td>".
			"\n	<td><input type=\"text\" name=\"Nachname\" value=\"".$Mitarbeiter['Nname']."\" /></td>".
            "\n	<td><input type=\"text\" id =\"Eingabe\" name=\"Dienst_E_Mail\" value=\"".$Mitarbeiter['Dienst_E_Mail']."\" /></td>".
            "\n	<td><input type=\"text\" name=\"Str_HN\" value=\"".$Mitarbeiter['Str_HN']."\" /></td>".
            "\n	<td><input type=\"text\" name=\"Ort\" value=\"".$Mitarbeiter['Ort']."\" /></td>".
            "\n	<td><input type=\"text\" name=\"PLZ\" value=\"".$Mitarbeiter['PLZ']."\" /></td>".
            "\n	<td><input type=\"text\" name=\"Geb_Datum\" value=\"".$Mitarbeiter['Geb_Datum']."\" /></td>".
            "\n	<td>".$Mitarbeiter['Einstell_ZS']."</td>".
			"\n	<td><select name=\"Status\" > 
        <option>OK</option> 
        <option>Urlaub</option> 
        <option>Krank</option>  
      </select> </td>".
            "\n	<td>
              <input  type=\"submit\" name=\"Save\" value=\"Save\" /></td>".
			  "<td></td>
			   <td></td>".
			"\n  </tr>";
    }
	}
	
	// der tabellenfuß 1 mal 
    $table .="\n<tr>".
			"\n	<td><input type=\"text\" name=\"ID2\" value=\"\" readonly /></td>".
			"\n	<td><input type=\"text\" name=\"Vorname2\" value=\"\" /></td>".
			"\n	<td><input type=\"text\" name=\"Nachname2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" id =\"Eingabe\" name=\"Dienst_E_Mail2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" name=\"Str_HN2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" name=\"Ort2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" name=\"PLZ2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" name=\"Geb_Datum2\" value=\"\" /></td>".
            "\n	<td><input type=\"text\" id =\"Eingabe\" name=\"ET2\" value=\"".date("Y")."-".date("m")."-".date("m")." ".date("G").":".date("i").":".date("s")."\" readonly /></td>".
			"\n	<td><select name=\"Status2\" > 
        <option value=\"OK\">OK</option> 
        <option value=\"Urlaub\">Urlaub</option> 
        <option value=\"Krank\">Krank</option>  
      </select> </td>".
            "\n	<td>
              <input  type=\"submit\" name=\"Insert\" value=\"Insert\" /></td>".
			  "<td><input  type=\"password\" name=\"Passwort2\" placeholder=\"Passwort\" id=\"pswd\" /></td>".
			"\n  </tr>";
	$table .="\n	<tbody> \n</table></form>";
	return $table;
    }
?>