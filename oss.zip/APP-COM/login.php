<?php
  include_once "./src/php_funcs.php";    // 1 Variante
  include_once "./src/db_funcs.php";     // 2 Variante
  include_once "./src/html_funcs.php"; // holt nur Funktionen die er noch nicht hat 
  define( "MYDEBUG", true);
 // $wert1 = $_POST['login'];
 // $wert2 = $_POST['passwd'];
  //echo $wert1." ".$wert2;
    $select = "MitarbeiterID";
  $from = "login_mitarbeiter";
  $dbconn = dbconnect("HssUser","oss_test");
  //echo $dbconn->host_info;
  $login=$_POST['login'];
  //echo $login;
  $passwd=$_POST['passwd'];
  $wehre="Nickname";
  //echo $passwd;
  $uid=GetUidByLogin($dbconn,$login,$passwd,$select,$from,$wehre);
  //echo "Ihre UserID=".$uid;
    if ($uid=="")
  {
      $uid="False";
  }
  echo $uid;
  ?>