<?php
  include_once "./src/php_funcs.php";    // 1 Variante
  include_once "./src/db_funcs.php";     // 2 Variante
  include_once "./src/html_funcs.php"; // holt nur Funktionen die er noch nicht hat 
  define( "MYDEBUG", FALSE);
  $dbconn = dbconnect("HssUser","hss");

 $uid = GetRouteByUID($dbconn);
  //echo "Ihre UserID=".$uid;
    if ($uid=="")
  {
      $uid="False";
  }
 // DebugArr($uid);

  echo $uid;
?>