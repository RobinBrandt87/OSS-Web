<?php
  error_reporting(E_ALL);
  // $mydebug = true; besser als Konstante => global
	define( "MYDEBUG", true);

  ini_set( "session.use_cookies" , 0);
	session_name("HSS");
	session_start();

  include_once "./src/php_funcs.php";
  include_once "./src/db_funcs.php";
  include_once "./src/html_funcs.php";
  
	DebugArr( $_POST );
    DebugArr( $_SESSION );
    $dbconn = dbconnect("HssUser","oss_test");
    if(isset($_POST['Menu0']) )
    {//Wenn du eine Anfrage bekommst lösche den MenuMerker in der Session und setzte deinen 
         unset( $_SESSION['intern']);
         $_SESSION['intern'] = $_POST['Menu0'];
    } 
    if ($_SESSION['intern']=="Mitarbeiter")
    {// Wenn Dein Merker Im Menu ist Baue dich auf 
        
        $Mitarbeiter = GetMitarbeiterDaten($dbconn);
        
        $option = $_POST['Bearbeiten'];
        $Content = Print_MitarbeiterTable($Mitarbeiter , $option );

    }
    
    
    
    if(isset($_POST['Save']))
    {
        $Vorname = Eingebecheck($_POST['Vorname']);
        $Nachname = Eingebecheck($_POST['Nachname']);
        $Email = Eingebecheck($_POST['Dienst_E_Mail']);
        $Adresse = Eingebecheck($_POST['Str_HN']);
        $Ort = Eingebecheck($_POST['Ort']);
        $PLZ = Eingebecheck($_POST['PLZ']);
        $Geb = Eingebecheck($_POST['Geb_Datum']);
        $Status = Eingebecheck($_POST['Status']);
        $dbconn = dbconnect("HssUser","oss_test");
        $ID = $_POST['ID'];
       /* 
       $sql = "UPDATE `oss_test`.`mitarbeiter`".
              "SET `Vname` = '".$Vorname."',". 
                 " `Nname` = '".$Nachname."',". 
                 " `Dienst_E_Mail` = '".$Email."',". 
                 " `Str_HN` = '".$Adresse."',". 
                 " `Ort` = '".$Ort."',". 
                 " `PLZ` = '".$PLZ."',". 
                 " `Status_MA` = '".$Status."'". 
                 " WHERE `mitarbeiter`.`MitarbeiterID` = '".$ID."';"; 
             $dbconn->query($sql); 
             */
              $sql = "UPDATE `oss_test`.`mitarbeiter`".
              "SET `Vname` = ?,". 
                 " `Nname` = ?,". 
                 " `Dienst_E_Mail` = ?,". 
                 " `Str_HN` = ?,". 
                 " `Ort` = ?,". 
                 " `PLZ` = ?,". 
                 " `Status_MA` = ?". 
                 " WHERE `mitarbeiter`.`MitarbeiterID` = ? ;";   
             $prepstmt = $dbconn->stmt_init();
             $prepstmt->prepare($sql); 
             $prepstmt->bind_param("ssssssss", $Vorname, $Nachname, $Email, $Adresse, $Ort, $PLZ , $Status , $ID);
             $prepstmt->execute();    
             
            if ($prepstmt->execute() === TRUE) {
            echo "Record updated successfully";
            echo $sql;
            //$ziel="./intern.php?".session_name()."=".session_id();
		    $ziel="./intern.php?".SID;
			// Umlenkung nach inter.php mit einer Session
			header("Location: $ziel"); 

        } else {
            echo "Error updating record: " . $conn->error;
        }
    } 
    if(isset($_POST['Sperren']))   
    {
         $dbconn = dbconnect("HssUser","oss_test");
         SperreLogin($dbconn,$_POST['Sperren'] );
            //$ziel="./intern.php?".session_name()."=".session_id();
		    $ziel="./intern.php?".SID;
			// Umlenkung nach inter.php mit einer Session
			header("Location: $ziel");        

    }
        if(isset($_POST['Aktivieren']))   
    {
         $dbconn = dbconnect("HssUser","oss_test");
         EntSperreLogin($dbconn,$_POST['Aktivieren'] );
            //$ziel="./intern.php?".session_name()."=".session_id();
		    $ziel="./intern.php?".SID;
			// Umlenkung nach inter.php mit einer Session
			header("Location: $ziel");
    }
     if(isset($_POST['Insert']))
    {
     $Vorname = Eingebecheck($_POST['Vorname2']);
        $Nachname = Eingebecheck($_POST['Nachname2']);
        $Email = Eingebecheck($_POST['Dienst_E_Mail2']);
        $Adresse = Eingebecheck($_POST['Str_HN2']);
        $Ort = Eingebecheck($_POST['Ort2']);
        $PLZ = Eingebecheck($_POST['PLZ2']);
        $Geb = Eingebecheck($_POST['Geb_Datum2']);
        $Status = Eingebecheck($_POST['Status2']);
        $Passwort = $_POST['Passwort2'];
        $ET = $_POST['ET2'];
        $dbconn = dbconnect("HssUser","oss_test");
        
       $sql1 ="INSERT INTO `mitarbeiter`(". 
                                        "`Vname`, `Nname`, ". 
                                        "`Dienst_E_Mail`, ". 
                                        "`Str_HN`, `Ort`, ". 
                                        "`PLZ`, `Geb_Datum`, ". 
                                        "`Einstell_ZS`, `Status_MA`) ". 
              "VALUES (?,?,?,?,?,?,?,?,?)"; 

             $prepstmt1 = $dbconn->stmt_init();
             $prepstmt1->prepare($sql1); 
             $prepstmt1->bind_param("sssssssss", $Vorname, $Nachname, $Email, $Adresse, $Ort, $PLZ, $Geb, $ET, $Status);
             $prepstmt1->execute();
             
        $sql2 = "INSERT INTO `login_mitarbeiter`
             (`MitarbeiterID`, `Nickname`, `Passwort`, `Login_ZS`, `Status`)". 
             "VALUES ( ? ,? , SHA2( ? , 512 ) , ? , ? )"; 
            // $prepstmt2 = $dbconn->stmt_init();
            // $prepstmt2->prepare($sql1); 
            // $prepstmt2->bind_param("issss", $Nachname, $Passwort, $ET , "Gesperrt" );
            //  $prepstmt2->execute();
            echo "Record updated successfully";
            //echo $prepstmt1;
            //$ziel="./intern.php?".session_name()."=".session_id();
		    $ziel="./intern.php?".SID;
			// Umlenkung nach inter.php mit einer Session
		    header("Location: $ziel"); 
   
        
    }
// Beginn des Hauptprogrammes
Check_LoggedIn()


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
  <title>OSS - Intern</title>
  <meta http-equiv="content-type" 
        content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="OSS.css" />
      <link rel="stylesheet" type="text/css" href="Menu.css" />
</head>
<body>
<div id="header">
  <h1>Objekt-Securety-System</h1>
</div>
<form id="Menu" action="<?php echo $_SERVER['PHP_SELF'].'?'.SID; ?>"
	      method="post">
<div id="Menu">
    <div class="MenuButton">
      <input type="submit" name="Menu0" value="Mitarbeiter" />
      <input type="submit" name="Menu1" value="Nachrichten" />
      <input type="submit" name="Menu2" value="Routen" />
      <input type="submit" name="Menu3" value="Protokolle" />
      <input type="submit" name="Menu4" value="Meine Daten Verwalten" />
      <input type="submit" name="Menu5" value="Objekte Verwalten" />
    </div>       
</div> 
</form>           
<div id="center">
<?php echo $Content;  ?>

</div>
<div id="footer">
  <a href="">Infos</a> &mdash;
  <a href="">Admin</a> &mdash;
  <a href="">Startseite</a>
</div>
</body>
</html>